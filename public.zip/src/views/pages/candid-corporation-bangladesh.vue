<template>
	<span>
		<div class="slider-area">
    <div class="single-slider slider-bg3 hero-overly slider-height2 d-flex align-items-center">
       <div class="container">
            <div class="row justify-content-center ">
				<div class="col-xl-12">
					<div class="hero-caption hero-caption2 text-center">
					    <h2> Candid Corporation Bangladesh </h2>
					</div>
				</div>
            </div>
        </div>
    </div>
</div>


<section class="concern-area">
	<div class="container">
		<div class="row">
			    <div class="col-md-4">
			    	 <div class="concern-image">
				 	    <img :src="'./front-end/img/gallery/gallery3.jpg'" alt="">
				     </div>
			    </div>
			    <div class="col-md-8">
			    	 <div class="concern-content">
				 	<p>
				 		Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
				 	</p>

				 	<p>
				 		Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
				 	</p>


				 </div>
			    </div>
		</div>
	</div>
</section>
	</span>
</template>