<template>
	<span>
		<main>

<div class="slider-area">
<div class="slider-active dot-style">

<div class="single-slider slider-height hero-overly slider-bg1 d-flex align-items-center">
<div class="container">
<div class="row justify-content-center">
<div class="col-xl-7">
<div class="hero-caption text-center">
<h1 data-animation="fadeInUp" data-delay=".4s">Best technology and awesome service we offer</h1>
<p data-animation="fadeInUp" data-delay=".4s">Ullamcorper fringi tortor consec adipis elit sed do eiusmod tempor.</p>
<a href="services.html" class="btn_10 hero-btn" data-animation="bounceIn" data-delay=".8s">Check Our Services 
	<img :src="`front-end/img/icon/right-arrow.svg`" alt></a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


<section class="categories-area section-bg">
<div class="container">
<div class="row">
<div class="col-xl-6 col-lg-8 col-md-9">
<div class="section-tittle mb-70">
<span>Services</span>
<h2>A height level service provider that recommended to any companies</h2>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-3 col-md-4 col-sm-6">
<div class="single-cat text-center mb-30">
<div class="cat-icon">
   <i class="fa-solid fa-oil-well"></i>
</div>
<div class="cat-cap">
<h5>Power and Energ</h5>
<a href="#" class="browse-btn2">Learn More <i class="fa-solid fa-arrow-right"></i></a>
</div>
</div>
</div>
<div class="col-lg-3 col-md-4 col-sm-6">
<div class="single-cat text-center mb-30">
<div class="cat-icon">
   <i class="fa-solid fa-oil-well"></i>
</div>
<div class="cat-cap">
<h5>Power and Energ</h5>
<a href="#" class="browse-btn2">Learn More <i class="fa-solid fa-arrow-right"></i></a>
</div>
</div>
</div>
<div class="col-lg-3 col-md-4 col-sm-6">
<div class="single-cat text-center mb-30">
<div class="cat-icon">
<i class="fa-solid fa-oil-well"></i>
</div>
<div class="cat-cap">
<h5>Power and Energ</h5>
<a href="#" class="browse-btn2">Learn More <i class="fa-solid fa-arrow-right"></i></a>
</div>
</div>
</div>
<div class="col-lg-3 col-md-4 col-sm-6">
<div class="single-cat text-center mb-30">
<div class="cat-icon">
<i class="fa-solid fa-oil-well"></i>
</div>
<div class="cat-cap">
<h5>Power and Energ</h5>
<a href="#" class="browse-btn2">Learn More <i class="fa-solid fa-arrow-right"></i></a>
</div>
</div>
</div>
</div>
</div>
</section>


<div class="emargency-care section-img-bg2 fix" data-background="front-end/img/gallery/section-bg1.jpg">
<div class="container">
<div class="row justify-content-end">
<div class="col-xl8 col-lg-10 col-md-11">
<div class="single-emargency">
<div class="emargency-cap">
<h5><a href="#">We have all your needs, from micro
macro planning</a></h5>
<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable.</p>
<p class="emargenc-cap">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words.</p>
<a href="#" class="btn_10">Learn More<img :src="'front-end/img/icon/right-arrow.svg'" alt></a>
</div>
</div>
</div>
</div>
</div>
</div>


<section class="about-low-area fix">
<div class="container">
<div class="row justify-content-between align-items-center">
<div class="col-xl-6 col-lg-7 col-md-10">
<div class="about-caption">

<div class="section-tittle section-tittle3 mb-20">
<span>Why Choose Us</span>
<h2>We Are Largest Independent Manufacturing Company</h2>
</div>
<p class="about-cap-top">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable.</p>
<div class="row mt-40">
<div class="col-lg-6 col-md-6 col-sm-6">

<div class="single mb-30">
<div class="single-counter">
<span class="counter ">450</span>
<p class>+</p>
</div>
<div class="pera-count">
<p>Successfully completed projects</p>
</div>
</div>
</div>
<div class="col-lg-6 col-md-6 col-sm-6">

<div class="single mb-30">
<div class="single-counter">
<span class="counter ">860</span>
</div>
<div class="pera-count">
<p>Highly specialised employees</p>
</div>
</div>
</div>
</div>
<a href="#" class="btn_10">Learn More<img :src="'front-end/img/icon/right-arrow.svg'" alt></a>
</div>
</div>
<div class="col-xl-5 col-lg-5 col-md-7">
<div class="about-right-cap">

<div class="video-area section-img-bg2 d-flex align-items-center" data-background="front-end/img/gallery/video-bg.jpg">
<div class="container">
<div class="video-wrap position-relative">

<div class="video-icon">
<a class="popup-video btn-icon" href="https://www.youtube.com/watch?v=up68UAfH0d0">
<i class="fas fa-play"></i>
</a>
</div>
</div>
</div>
</div>

</div>
</div>
</div>
</div>
</section>


<div class="brand-area section-bg">
<div class="container">
<div class="row justify-content-center align-items-end">
<div class="col-xl-12">
<div class="brand-active  pt-50 pb-40">
<div class="single-brand">
<img :src="`front-end/img/gallery/brand1.png`" alt>
</div>
<div class="single-brand">
<img :src="`front-end/img/gallery/brand2.png`" alt>
</div>
<div class="single-brand">
<img :src="`front-end/img/gallery/brand3.png`" alt>
</div>
<div class="single-brand">
<img :src="`front-end/img/gallery/brand4.png`" alt>
</div>
<div class="single-brand">
<img :src="`front-end/img/gallery/brand2.png`" alt>
</div>
<div class="single-brand">
<img :src="`front-end/img/gallery/brand3.png`" alt>
</div>
</div>
</div>
</div>
</div>
</div>


<div class="guest-house">
<div class="container-fluid">
<div class="row">
<div class="col-md-6 col-sm-6 p-0">
<div class="single-location">
<img :src="'front-end/img/gallery/6.jpg'" alt>
<div class="guest-contents">
<p>Gas & Oil</p>
<h3><a href="#">Power and Energy</a></h3>
</div>
</div>
</div>
<div class="col-md-6 col-sm-6 p-0">
<div class="single-location">
<img :src="'front-end/img/gallery/2.jpg'" alt>
<div class="guest-contents">
<p>Gas & Oil</p>
<h3><a href="#">Power and Energy</a></h3>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 col-sm-6 p-0">
<div class="single-location">
<img :src="'front-end/img/gallery/3.jpg'" alt>
<div class="guest-contents">
<p>Gas & Oil</p>
<h3><a href="#">Power and Energy</a></h3>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 col-sm-6 p-0">
<div class="single-location">
<img :src="'front-end/img/gallery/4.jpg'" alt>
<div class="guest-contents">
<p>Gas & Oil</p>
<h3><a href="#">Power and Energy</a></h3>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6 col-sm-6 p-0">
<div class="single-location">
<img :src="'front-end/img/gallery/5.jpg'" alt>
<div class="guest-contents">
<p>Gas & Oil</p>
<h3><a href="#">Power and Energy</a></h3>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-12 p-0">
<a href="#" class="btn_10 w-100 text-center">More Project<img :src="'front-end/img/icon/right-arrow.svg'" alt></a>
</div>
</div>
</div>
</div>


<section class="testimonial-area fix top-padding">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-5 col-md-8 col-sm-10">
<div class="testimonial-hero">
<img :src="'front-end/img/gallery/testimonial-hero.png'" alt>
</div>
</div>
<div class=" col-lg-6">
<div class="row">
<div class="col-xl-12">

<div class="section-tittle section-tittle2 mb-25">
<h2>Testimonial</h2>
<p>Vestibulum ante ipsum primis in faucibus orci luctus.</p>
</div>
</div>
</div>

<div class="h1-testimonial-active dot-style">

<div class="single-testimonial position-relative">
<div class="testimonial-caption">
<img :src="'front-end/img/icon/quotes-sign.png'" alt>
<p>"The automated process starts as soon as your clothe go into the machine. This site outcome is gleaming clothe. Placeholder text commonly used. In publishing and graphic.</p>
</div>

<div class="testimonial-founder d-flex align-items-center">
<div class="founder-img">
<img :src="'front-end/img/icon/testimonial.png'" alt>
</div>
<div class="founder-text">
<span>Robart Brown</span>
<p>Creative designer at Colorlib</p>
</div>
</div>
</div>

<div class="single-testimonial position-relative">
<div class="testimonial-caption">
<img :src="'front-end/img/icon/quotes-sign.png'" alt>
<p>"The automated process starts as soon as your clothe go into the machine. This site outcome is gleaming clothe. Placeholder text commonly used. In publishing and graphic.</p>
</div>

<div class="testimonial-founder d-flex align-items-center">
<div class="founder-img">
<img :src="'front-end/img/icon/testimonial.png'" alt>
</div>
<div class="founder-text">
<span>Robart Brown</span>
<p>Creative designer at Colorlib</p>
</div>
</div>
</div>

<div class="single-testimonial position-relative">
<div class="testimonial-caption">
<img :src="'front-end/img/icon/quotes-sign.png'" alt>
<p>"The automated process starts as soon as your clothe go into the machine. This site outcome is gleaming clothe. Placeholder text commonly used. In publishing and graphic.</p>
</div>

<div class="testimonial-founder d-flex align-items-center">
<div class="founder-img">
<img :src="'front-end/img/icon/testimonial.png'" alt>
</div>
<div class="founder-text">
<span>Robart Brown</span>
<p>Creative designer at Colorlib</p>
</div>
</div>
</div>
</div>

</div>
</div>
</div>
</section>


<section class="wantToWork-area w-padding2">
<div class="container">
<div class="row align-items-center justify-content-between">
<div class="col-xl-5 col-lg-5 col-md-8">
<div class="wants-wrapper">
<div class="wantToWork-caption wantToWork-caption2">
<h2>Any help needed?</h2>
<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia.</p>
</div>
</div>
</div>
<div class="col-xl-3 col-lg-3 col-md-4">
<a href="#" class="btn_10 wantToWork-btn">Contact Us<img :src="'front-end/img/icon/right-arrow.svg'" alt></a>
</div>
</div>
</div>
</section>

</main>
	</span>
</template>