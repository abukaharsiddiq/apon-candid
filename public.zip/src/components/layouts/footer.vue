<template>
	<span>
		
<div class="col-md-12 footer-wrapper">

<div class="footer-area footer-padding">
<div class="container">
<div class="row justify-content-between">
<div class="col-xl-3 col-lg-3 col-md-6 col-sm-8">
<div class="single-footer-caption">
<div class="single-footer-caption">

<div class="footer-logo">
<a href=""><img :src="'front-end/img/logo/Candid Logo.png'" alt></a>
</div>
<div class="footer-tittle">
<div class="footer-pera">
<p>Duis aute irure dolor inasfa reprehenderit in voluptate velit esse cillum</p>
</div>
<ul class="mb-20">
<li class="number">
	<a href="#">+8802-4896 3197</a>
</li>
<li class="number2">
	<a href="#">
	   <span class="__cf_email__">corporationcandid@gmail.com</span>
    </a>
</li>
</ul>

<!-- <ul class="footer-social">
<li><a href="#"><i class="fab fa-instagram"></i></a></li>
<li><a href="https://bit.ly/sai4ull"><i class="fab fa-facebook"></i></a></li>
<li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
<li> <a href="#"><i class="fab fa-youtube"></i></a></li>
</ul> -->

</div>
</div>
</div>
</div>
<div class="offset-xl-1 col-xl-2 col-lg-2 col-md-4 col-sm-6">
<div class="single-footer-caption">
<div class="footer-tittle">
<h4>Navigation</h4>
<ul>
<li><a href="#">Home</a></li>
<li><a href="#">About</a></li>
<li><a href="#">Services</a></li>
<li><a href="#">Blog</a></li>
<li><a href="#">Contact</a></li>
</ul>
</div>
</div>
</div>
<div class="col-xl-2 col-lg-2 col-md-4 col-sm-6">
<div class="single-footer-caption">
<div class="footer-tittle">
<h4>Services</h4>
<ul>
<li><a href="#">Drone Mapping</a></li>
<li><a href="#"> Real State</a></li>
<li><a href="#">Commercial</a></li>
<li><a href="#">Construction</a></li>
</ul>
</div>
</div>
</div>
<div class="col-xl-4 col-lg-4 col-md-6 col-sm-8">
<div class="single-footer-caption">
<div class="footer-tittle mb-50">
<h4>Subscribe newsletter</h4>
<p>Subscribe our newsletter to get updates about our services and offers.</p>
</div>

<div class="footer-form">
<div id="mc_embed_signup">
<form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="subscribe_form relative mail_part">
<input type="email" name="email" id="newsletter-form-email" placeholder="Email Address" class="placeholder hide-on-focus" onfocus="this.placeholder = ''" onblur="this.placeholder = ' Email Address '">
<div class="form-icon">
<button type="submit" name="submit" id="newsletter-submit" class="email_icon newsletter-submit button-contactForm"><img src="assets/img/icon/right-arrow3.svg" alt></button>
</div>
<div class="mt-10 info"></div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="footer-bottom-area">
<div class="container">
<div class="footer-border">
<div class="row">
<div class="col-xl-12 ">
<div class="footer-copy-right text-center">
<p>Copyright &copy;2023 All Rights Reserved | Design And Developed by 
	<a href="" target="_blank">DoofazIT Limited</a>
</p>
</div>
</div>
</div>
</div>
</div>
</div>

</div>


<div class="search-model-box">
<div class="h-100 d-flex align-items-center justify-content-center">
<div class="search-close-btn">+</div>
<form class="search-model-form">
<input type="text" id="search-input" placeholder="Searching key.....">
</form>
</div>
</div>


<div id="back-top">
<a class="wrapper" title="Go to Top" href="#">
<div class="arrows-container">
<div class="arrow arrow-one">
</div>
<div class="arrow arrow-two">
</div>
</div>
</a>
</div>
	</span>
</template>