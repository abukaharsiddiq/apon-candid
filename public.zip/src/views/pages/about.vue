<template>
	<span>
		<div class="slider-area">
    <div class="single-slider slider-bg3 hero-overly slider-height2 d-flex align-items-center">
       <div class="container">
            <div class="row justify-content-center ">
				<div class="col-xl-12">
					<div class="hero-caption hero-caption2 text-center">
					    <h2>About Us</h2>
					</div>
				</div>
            </div>
        </div>
    </div>
</div>

<section class="about-area pt-50 pb-40">
	<div class="container">
		<!-- vision and values -->
		<div class="row">

			<div class="vision-values">
				 <div class="about-heading">
				 	<h4>Vision and Values</h4>
				 </div>
				 <p>
				 	To create value for all stakeholders by developing a diversified portfolio that builds on our core competencies and to do so in an ethical and socially responsible manner.
				 </p>

				 <div class="vision-values-list">
				 	<ul>
				 		<li>
				 		     <b><i class="fa fa-bullet"></i>Integrity</b><br/>
				 		     <em>
				 		     	To be honest in all our dealings with colleagues, customers, suppliers, shareholders and all other stakeholders.
				 		     </em>
				 	    </li>

				 	    <li>
				 		     <b>Accountability</b><br/>
				 		     <em>
				 		     	To recognise and be conscious of our impact on the community that we work in and to positively impact our environment and society.
				 		     </em>
				 	    </li>

				 	    <li>
				 		     <b>Performance Driven</b><br/>
				 		     <em>
				 		     	To strive to deliver superior products in the most efficient and effective manner.
				 		     </em>
				 	    </li>

				 	    <li>
				 		     <b>Reliability</b><br/>
				 		     <em>
				 		     	To be responsive and proactive on meeting commitments, and to be responsible and accountable for the same
				 		     </em>
				 	    </li>

				 	    <li>
				 		     <b>Continuous Improvement</b><br/>
				 		     <em>
				 		     	To constantly adapt to customer needs and changing environments and to improve current processes in order to maximise value.
				 		     </em>
				 	    </li>

				 	    <li>
				 		     <b>Simplicity and Humility</b><br/>
				 		     <em>
				 		     	To maintain a friendly attitude with all stakeholders and stay true to our belief 'Bonds build Businesses'.
				 		     </em>
				 	    </li>
				 	</ul>
				 </div>

			</div>

			

		</div>
		<!-- vision and values -->

       <!--  facilities -->
        <div class="row mt-40">
        	<div class="facilities-area">
        		 <div class="facilities-heading">
        		 	<h4>Facilities</h4>
        		 </div>
        		 <div class="row">
        		 	
        		 	<div class="col-md-6">
        		 		<div class="facilities-content">
        		 			<p>
        		 				The Company has its registered office at Nariman Point, Mumbai and three manufacturing facilities - one is located in Turbhe, Navi Mumbai, Maharashtra and the other two in Silvassa - Union Territory of Dadra & Nagar Haveli at Kharadpada and Silli.</p>

                             <p>   The Company’s latest plant in Silli, Silvassa is a fully automated state of the art manufacturing unit that started operations in 2013.</p>

                             <p>   The Company has so far set up a number of windmills ranging in capacities from 350 KW to 1650 KW at different sites in the states of Maharashtra, Karnataka and Tamil Nadu. This is an ongoing process and Savita continues to explore new opportunities in this field.
        		 			</p>
        		 		</div>
        		 	</div>

        		 	<div class="col-md-6">
        		 		<div class="facilities-image">
        		 			<img :src="'./front-end/img/about/header_facilities.jpg'" alt="">
        		 		</div>
        		 	</div>

        		 </div>
        	</div>
        </div>
       <!--  facilities -->

      <!--  corporate governance -->
      <div class="row mt-40">
      	  <div class="corporate-governance">
      	  	   <div class="corporate-governance-heading">
        		 	<h4> Corporate Governance</h4>
        		</div>

        		<div class="corporate-address mt-40">
        			<h6>REGISTERED OFFICE</h6>

        			<span><i class="ti-home"></i>House-17, Road-14, Sector-13, Uttara, Dhaka-1230</span><br/>
        			<span><i class="ti-tablet"></i>+8802-4896 3197</span><br/>
        			<span><i class="ti-email"></i>corporationcandid@gmail.com</span><br/>
        			
        		</div>

        		<div class="corporate-address mt-40">
        			<h6>NATURE OF BUSINESS UNDERTAKEN BY THE COMPANY</h6>
        			<p>
        				The Company is engaged in the business of manufacturing and marketing of petroleum specialty products and also in generation of wind energy.
        			</p>
        		</div>

        		<div class="corporate-address mt-40">
        			<h6>REGISTRARS & SHARE TRANSFER AGENTS</h6>
        			<span>
	        			Link Intime India Pvt. Ltd.<br/>
						C/13, Pannalal Silk Mills Compound,<br/>
						L. B. S. Marg, Bhandup (W),<br/>
						Mumbai  400 078
					</span><br/>
        			<span>Phone: +91-22-2594 6970</span><br/>
        			<span>Fax : +91-22-2594 6969</span><br/>
        			<span>Email: rnt.helpdesk@linkintime.co.in</span><br/>
        			<span>Web : www.linkintime.co.in</span><br/>
        		</div>

        		<div class="corporate-address mt-40">
        			<h6>CORPORATE GOVERNANCE COMPLIANCE</h6>
        			<p>
        				The Company has complied with all mandatory requirements of clause 49 of the Listing Agreement executed with the Stock Exchanges.
        			</p>
        		</div>

        		<div class="corporate-address mt-40">
        			<h6>AGREEMENTS WITH MEDIA COMPANIES</h6>
        			<p>
        				The Company during the course of its business enters into agreements with media companies from time to time. However, as on date none of the said media companies are shareholders of the Company as referred to in clause 53 of the Listing Agreement.
        			</p>
        		</div>

        		<div class="corporate-address mt-40">
        			<h6>SHAREHOLDING PATTERN</h6>
        			<p>
        				The detailed shareholding pattern of the Company is provided from time to time on the website of the Company. The same is also filed with the Stock Exchanges from time to time.
        			</p>
        		</div>

      	  </div>
      </div>
      <!--  corporate governance -->

	</div>
</section>
	</span>
</template>