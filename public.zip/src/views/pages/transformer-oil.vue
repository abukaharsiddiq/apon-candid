<template>
	<span>
		<div class="slider-area">
    <div class="single-slider slider-bg3 hero-overly slider-height2 d-flex align-items-center">
       <div class="container">
            <div class="row justify-content-center ">
				<div class="col-xl-12">
					<div class="hero-caption hero-caption2 text-center">
					    <h2>Transformer Oil</h2>
					</div>
				</div>
            </div>
        </div>
    </div>
</div>


<section class="transform-oil-area pt-30 pb-30">
	<div class="container">

		<div class="row pb-40">
			<div class="transform-oil">
				<div class="row">
					<div class="oil-heading">
				      <h4>Transol</h4>
			        </div>
			<div class="col-md-8">
				<div class="oil-content">
					<p>
						Transformer Oils are electrical insulating oils produced by distillation of virgin paraffinic and naphthenic crude oils followed by modern technologies involving high pressure hydrogenation and hydro-treatment. All the processes are monitored closely and appropriate Base Oil fractions are selected for further processing. Further processing involves removal of moisture and polar impurities to obtain good electrical properties. 
					</p>
					<p>
						The technologies result in products with very low pour point, excellent oxidation stability, cooling characteristics and electrical properties. These properties make them suitable for the most demanding transformer applications.
					</p>
				</div>
			</div>

			<div class="col-md-4">
				<div class="oil-image">
					<img :src="'./front-end/img/gallery/img_transol.jpg'" alt="">
				</div>
			</div>

				</div>
			</div>
		</div>

		<div class="row pb-40">
			<div class="transform-oil">
				<div class="row">
					<div class="oil-heading">
				      <h4>Bio Transol</h4>
			        </div>

			        <div class="col-md-4">
				<div class="oil-image">
					<img :src="'./front-end/img/gallery/gallery2.jpg'" alt="">
				</div>
			</div>

			<div class="col-md-8">
				<div class="oil-content">
					<p>
						Transformer Oils are electrical insulating oils produced by distillation of virgin paraffinic and naphthenic crude oils followed by modern technologies involving high pressure hydrogenation and hydro-treatment. All the processes are monitored closely and appropriate Base Oil fractions are selected for further processing. Further processing involves removal of moisture and polar impurities to obtain good electrical properties. 
					</p>
					<p>
						The technologies result in products with very low pour point, excellent oxidation stability, cooling characteristics and electrical properties. These properties make them suitable for the most demanding transformer applications.
					</p>
				</div>
			</div>
			
			

				</div>
			</div>
		</div>

		<div class="row pb-40">
			<div class="transform-oil">
				<div class="row">
					<div class="oil-heading">
				      <h4>Transol-Synth</h4>
			        </div>

			        

						<div class="col-md-8">
							<div class="oil-content">
								<p>
									Transformer Oils are electrical insulating oils produced by distillation of virgin paraffinic and naphthenic crude oils followed by modern technologies involving high pressure hydrogenation and hydro-treatment. All the processes are monitored closely and appropriate Base Oil fractions are selected for further processing. Further processing involves removal of moisture and polar impurities to obtain good electrical properties. 
								</p>
								<p>
									The technologies result in products with very low pour point, excellent oxidation stability, cooling characteristics and electrical properties. These properties make them suitable for the most demanding transformer applications.
								</p>
							</div>
						</div>

						<div class="col-md-4">
					        <div class="oil-image">
						      <img :src="'./front-end/img/gallery/img_transol.jpg'" alt="">
					        </div>
			            </div>
			
			

				</div>
			</div>
		</div>

	</div>
</section>
	</span>
</template>