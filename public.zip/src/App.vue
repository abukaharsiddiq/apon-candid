<script setup>
import { RouterLink, RouterView } from 'vue-router'
import Master from '@/views/Master.vue';
</script>

<template>
   <Master></Master>
</template>

<style scoped>

</style>
